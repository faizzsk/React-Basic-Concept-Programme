import react, { Component, Fragment } from 'react'

class FragmentDemo extends Component{


    render()
    {
        return(
                <Fragment>
                    <h1>Hi </h1>
                </Fragment>
        )
    }

}
export default FragmentDemo